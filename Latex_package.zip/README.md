# ifacconf_latex
LaTeX class for IFAC-PapersOnline manuscripts
