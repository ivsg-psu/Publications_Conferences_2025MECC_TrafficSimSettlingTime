# Copyright notice

 **ifacconf.cls** : Adapted from **ifacmgt.cls**   
   Copyright ©1995 Elsevier Science Ltd  
   Copyright ©2008 Juan A. de la Puente, International Federation of Automatic Control  
   *All rights reserved*

**ifacconf.bst** : Adapted from **merlin.mbs**  
   Copyright ©1994-2007 Patrick W Daly  
   Copyright ©2011 Juan A. de la Puente, International Federation of Automatic Control   
   *LaTeX Project Public License*  

Sample files: **ifacconf.tex**, **ifacconf.bib**, **bifurcation.eps**, **bifurcation.jpg**  
   Copyright ©2008-2011 Juan A. de la Puente, International Federation of Automatic Control   
   *LaTeX Project Public License*  

